#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <iostream.h>

#define INCFR 3.0

void initalize(void);
void draw(void);
void update(void);
void animate(void);
void make_light1(void);
void make_light2(void);
void make_light3(void);
void make_light4(void);
void make_material1(void);
void make_material2(void);
void body(void);
void camera(void);
void rightleg(void);
void leftleg(void);
void chest(void);
void rightarm(void);
void leftarm(void);
void head(void);
void keys(int key, int x, int y);


float r_eje_antebrazo=0.0;
float r_eje_brazo=0.0;
float l_eje_antebrazo=0.0;
float l_eje_brazo=0.0;
float r_eje_muslo=0.0;
float r_eje_pechuga=0.0;
float l_eje_muslo=0.0;
float l_eje_pechuga=0.0;
int r_arm_position=0;
int l_arm_position=0;
int r_leg_position=0;
int l_leg_position=0;
GLUquadricObj *rltop;
GLUquadricObj *rlbot;
GLUquadricObj *lltop;
GLUquadricObj *llbot;
GLUquadricObj *ratop;
GLUquadricObj *rabot;
GLUquadricObj *latop;
GLUquadricObj *labot;
GLUquadricObj *chr;
GLUquadricObj *chl;
GLUquadricObj *cht;


/////////////////////////////////////////
void main(int argc, char* argv[])
{
glutInit(&argc, argv);
glutInitDisplayMode(GLUT_DOUBLE |GLUT_RGB|GLUT_DEPTH);
glutInitWindowSize(400, 400);
glutInitWindowPosition(400, 400);
glutCreateWindow("New Glut");
glutDisplayFunc(draw);
initalize();
update();
glutIdleFunc(animate);
glutMainLoop();
}
////////////////////////////////////////
void animate(void){
update();
glutPostRedisplay();	
}

void initalize(void)
{
latop=gluNewQuadric(); 
labot=gluNewQuadric(); 
ratop=gluNewQuadric(); 
rabot=gluNewQuadric(); 
}

void draw(void)
{
	glClearColor(1.0, 0.0, 0.0, 0.0);
	
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_DEPTH_TEST);
	make_light1();	
	make_light2();
	make_light3();
	make_light4();
	camera();
	glPushMatrix();
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glutSpecialFunc(keys);
	body();
	glDisable(GL_LIGHTING);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_LIGHT2);
	glDisable(GL_LIGHT3);
	glDisable(GL_NORMALIZE);
	glDisable(GL_DEPTH_TEST);
	glPopMatrix();
	glutSwapBuffers();
}

void update(void)
{
// Chequeando brazo derecho
	if(r_arm_position==1)
{
	if(r_eje_antebrazo<90.0){
	r_eje_antebrazo=r_eje_antebrazo+INCFR;
	r_eje_brazo=r_eje_brazo-INCFR;
	}
	else if(r_eje_antebrazo==90.0 && r_eje_brazo<0.0){
		r_eje_brazo=r_eje_brazo+INCFR;
	}
}


if(r_arm_position==0)
{
	if(r_eje_antebrazo>0.0){
		r_eje_antebrazo=r_eje_antebrazo-INCFR;
		if(r_eje_brazo<0.0)
		r_eje_brazo=r_eje_brazo+INCFR;
	}
}

// Chequeando brazo izquierdo
	if(l_arm_position==1)
{
	if(l_eje_antebrazo>-90.0){
	l_eje_antebrazo=l_eje_antebrazo-INCFR;
	l_eje_brazo=l_eje_brazo+INCFR;
	}
	else if(l_eje_antebrazo==-90.0 && l_eje_brazo>0.0){
		l_eje_brazo=l_eje_brazo-INCFR;
	}
}


if(l_arm_position==0)
{
	if(l_eje_antebrazo<0.0){
		l_eje_antebrazo=l_eje_antebrazo+INCFR;
		if(l_eje_brazo>0.0)
		l_eje_brazo=l_eje_brazo-INCFR;
	}
}

// Chequeando pierna derecha

	if(r_leg_position==1)
{
	if(r_eje_muslo<90.0){
	r_eje_muslo=r_eje_muslo+INCFR;
	r_eje_pechuga=r_eje_pechuga-INCFR;
	}
	else if(r_eje_muslo==90.0 && r_eje_pechuga<0.0){
		r_eje_pechuga=r_eje_pechuga+INCFR;
	}
}


if(r_leg_position==0)
{
	if(r_eje_muslo>0.0){
		r_eje_muslo=r_eje_muslo-INCFR;
		if(r_eje_pechuga<0.0)
		r_eje_pechuga=r_eje_pechuga+INCFR;
	}
}

// Chequeando pierna izquierda

	if(l_leg_position==1)
{
	if(l_eje_muslo<90.0){
	l_eje_muslo=l_eje_muslo+INCFR;
	l_eje_pechuga=l_eje_pechuga-INCFR;
	}
	else if(l_eje_muslo==90.0 && l_eje_pechuga<0.0){
		l_eje_pechuga=l_eje_pechuga+INCFR;
	}
}


if(l_leg_position==0)
{
	if(l_eje_muslo>0.0){
		l_eje_muslo=l_eje_muslo-INCFR;
		if(l_eje_pechuga<0.0)
		l_eje_pechuga=l_eje_pechuga+INCFR;
	}
}


}

void make_light1(void)
{
GLfloat light_ambient[] = {1.0, 1.0, 1.0, 1.0};  
GLfloat light_diffuse[] = {0.5, 0.5, 0.5, 0.5};  
GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};  
GLfloat light_position[] = {10.0, 10.0, -10.0, 1.0};
GLfloat spot_direction[] = {0.0, 0.0, 0.0};
glLightfv(GL_LIGHT0, GL_AMBIENT,light_ambient);
glLightfv(GL_LIGHT0, GL_DIFFUSE,light_diffuse);
glLightfv(GL_LIGHT0, GL_SPECULAR,light_specular);
glLightfv(GL_LIGHT0, GL_POSITION, light_position);
glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spot_direction);
glEnable(GL_LIGHTING);
glEnable(GL_LIGHT0);
glEnable(GL_NORMALIZE);
}

void make_light2(void)
{
GLfloat light_ambient[] = {1.0, 1.0, 1.0, 1.0};  
GLfloat light_diffuse[] = {0.5, 0.5, 0.5, 0.5};  
GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};  
GLfloat light_position[] = {-10.0, 10.0, -10.0, 1.0};
GLfloat spot_direction[] = {0.0, 0.0, 0.0};
glLightfv(GL_LIGHT1, GL_AMBIENT,light_ambient);
glLightfv(GL_LIGHT1, GL_DIFFUSE,light_diffuse);
glLightfv(GL_LIGHT1, GL_SPECULAR,light_specular);
glLightfv(GL_LIGHT1, GL_POSITION, light_position);
glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spot_direction);
glEnable(GL_LIGHT1);
}

void make_light3(void)
{
GLfloat light_ambient[] = {1.0, 1.0, 1.0, 1.0};  
GLfloat light_diffuse[] = {0.5, 0.5, 0.5, 0.5};  
GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};  
GLfloat light_position[] = {-10.0, -10.0, -10.0, 1.0};
GLfloat spot_direction[] = {0.0, 0.0, 0.0};
glLightfv(GL_LIGHT2, GL_AMBIENT,light_ambient);
glLightfv(GL_LIGHT2, GL_DIFFUSE,light_diffuse);
glLightfv(GL_LIGHT2, GL_SPECULAR,light_specular);
glLightfv(GL_LIGHT2, GL_POSITION, light_position);
glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, spot_direction);
glEnable(GL_LIGHT2);
}

void make_light4(void)
{
GLfloat light_ambient[] = {1.0, 1.0, 1.0, 1.0};  
GLfloat light_diffuse[] = {0.5, 0.5, 0.5, 0.5};  
GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};  
GLfloat light_position[] = {10.0, -10.0, -10.0, 1.0};
GLfloat spot_direction[] = {0.0, 0.0, 0.0};
glLightfv(GL_LIGHT3, GL_AMBIENT,light_ambient);
glLightfv(GL_LIGHT3, GL_DIFFUSE,light_diffuse);
glLightfv(GL_LIGHT3, GL_SPECULAR,light_specular);
glLightfv(GL_LIGHT3, GL_POSITION, light_position);
glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, spot_direction);
glEnable(GL_LIGHT3);
}

void make_material1(void)
{
    GLfloat emission[] = {0.0, 0.0, 0.0, 1.0};
    GLfloat ambient[] = {0.0, 0.0, 0.0, 1.0};
    GLfloat diffuse[] = {1.0, 1.0, 0.0, 1.0};
    GLfloat specular[] = {0.7, 0.7, 0.7, 0.7};
    GLfloat shininess[] = {70.0};
    glMaterialfv(GL_FRONT, GL_EMISSION,emission );
    glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,diffuse  );
    glMaterialfv(GL_FRONT, GL_SPECULAR,specular );
    glMaterialfv(GL_FRONT, GL_SHININESS,shininess );
}

void make_material2(void)
{
    GLfloat emission[] = {0.0, 0.0, 0.0, 1.0};
    GLfloat ambient[] = {0.0, 0.0, 0.0, 1.0};
    GLfloat diffuse[] = {0.2, 0.5, 1.0, 1.0};
    GLfloat specular[] = {0.7, 0.7, 0.7, 0.7};
    GLfloat shininess[] = {70.0};
    glMaterialfv(GL_FRONT, GL_EMISSION,emission );
    glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,diffuse  );
    glMaterialfv(GL_FRONT, GL_SPECULAR,specular );
    glMaterialfv(GL_FRONT, GL_SHININESS,shininess );
}

void body(void)
{

make_material1();
glutSolidIcosahedron();
rightleg();
leftleg();
chest();
rightarm();
leftarm();
head();
}

void camera(void)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(40.0, 1.0, .1, 200);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(15.0, 10.0, -30.0, 0, 0, 0, 0, 1, 0);
}

void rightleg(void)
{
rltop=gluNewQuadric(); 
rlbot=gluNewQuadric(); 
glPushMatrix();
glTranslatef(1.2, 0.0, 1.0);
glRotatef(r_eje_muslo, 1.0, 0.0, 0.0);
make_material2();
gluCylinder(rltop, .3, .3, 3,  5, 5);
make_material1();
glTranslatef(0.0, 0.0, 3.8);
glScalef(0.5,0.5,0.5);
glutSolidIcosahedron();
glScalef(2.0,2.0,2.0);
glTranslatef(0.0, 0.0, 1.0);
glRotatef(r_eje_pechuga, 1.0, 0.0, 0.0);
make_material2();
gluCylinder(rlbot, .3, .3, 3,  5, 5);
glPopMatrix();
}

void leftleg(void)
{
lltop=gluNewQuadric(); 
llbot=gluNewQuadric(); 
glPushMatrix();
glTranslatef(-1.2, 0.0, 1.0);
glRotatef(l_eje_muslo, 1.0, 0.0, 0.0);
make_material2();
gluCylinder(lltop, .3, .3, 3,  5, 5);
make_material1();
glTranslatef(0.0, 0.0, 3.8);
glScalef(0.5,0.5,0.5);
glutSolidIcosahedron();
glScalef(2.0,2.0,2.0);
glTranslatef(0.0, 0.0, 1.0);
glRotatef(l_eje_pechuga, 1.0, 0.0, 0.0);
make_material2();
gluCylinder(llbot, .3, .3, 3,  5, 5);
glPopMatrix();
}

void chest(void)
{
chr=gluNewQuadric(); 
chl=gluNewQuadric(); 
cht=gluNewQuadric(); 
glPushMatrix();
glTranslatef(2.0, 0.0, -5.0);
glRotatef(-20.0, 0.0, 1.0, 0.0);
make_material2();
gluCylinder(chr, .3, .3, 4,  5, 5);
glTranslatef(-3.9, 0.0, 1.4);
glRotatef(40.0, 0.0, 1.0, 0.0);
gluCylinder(chr, .3, .3, 4,  5, 5);
glTranslatef(0.2, 0.0, -0.5);
glRotatef(70.0, 0.0, 1.0, 0.0);
gluCylinder(cht, .3, .3, 4.2,  5, 5);
glPopMatrix();
}

void rightarm(void)
{
glPushMatrix();
glTranslatef(3.0, 0.0, -5.5);
glRotatef(r_eje_antebrazo, 0.0, 1.0, 0.0);
make_material2();
gluCylinder(ratop, .3, .3, 2.2,  5, 5);
make_material1();
glTranslatef(0.0, 0.0, 3.0);
glScalef(0.5,0.5,0.5);
glutSolidIcosahedron();
glScalef(2.0,2.0,2.0);
glTranslatef(0.0, 0.0, 0.8);
glRotatef(r_eje_brazo, 0.0, 1.0, 0.0);
make_material2();
gluCylinder(rabot, .3, .3, 2.2,  5, 5);
glPopMatrix();
}

void leftarm(void)
{

glPushMatrix();
glTranslatef(-3.0, 0.0, -5.5);
glRotatef(l_eje_antebrazo, 0.0, 1.0, 0.0);
make_material2();
gluCylinder(latop, .3, .3, 2.2,  5, 5);
make_material1();
glTranslatef(0.0, 0.0, 3.0);
glScalef(0.5,0.5,0.5);
glutSolidIcosahedron();
glScalef(2.0,2.0,2.0);
glTranslatef(0.0, 0.0, 0.8);
glRotatef(l_eje_brazo, 0.0, 1.0, 0.0);
make_material2();
gluCylinder(labot, .3, .3, 2.2,  5, 5);
glPopMatrix();
}

void head(void)
{
glPushMatrix();
make_material1();
glTranslatef(0.0, 0.0, -7.8);
glutSolidSphere(1.5,10,10);
glPopMatrix();
}

void keys(int key, int x, int y){

	if(key==GLUT_KEY_LEFT){
		if(r_arm_position==0)
		r_arm_position=1;
		else if(r_arm_position==1)
			r_arm_position=0;
	}

	if(key==GLUT_KEY_RIGHT){ 		
		if(l_arm_position==0)
		l_arm_position=1;
		else if(l_arm_position==1)
		l_arm_position=0;
	}

	if(key==GLUT_KEY_UP){ 		
		if(l_eje_muslo<10.0){
		if(r_leg_position==0)
		r_leg_position=1;
		else if(r_leg_position==1)
		r_leg_position=0;
		}
	}
	if(key==GLUT_KEY_DOWN){ 		
		if(r_eje_muslo<10.0){
		if(l_leg_position==0)
		l_leg_position=1;
		else if(l_leg_position==1)
		l_leg_position=0;
		}
	}
	
}
